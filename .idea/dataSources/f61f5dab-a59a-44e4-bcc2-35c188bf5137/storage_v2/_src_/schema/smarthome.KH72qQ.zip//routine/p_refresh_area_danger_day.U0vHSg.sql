create
    definer = root@`%` procedure p_refresh_area_danger_day(IN fprobeid int, IN fchannel int, IN fday datetime)
begin
DECLARE
fareaid int;
DECLARE
fdangertimes int;
DECLARE
fmaxsvd int;
DECLARE
favgsvd int;
DECLARE
fminsvd int;
DECLARE
fmaxsv int;
DECLARE
favgsv int;
DECLARE
fminsv int;
DECLARE
fmaxsi int;
DECLARE
favgsi int;
DECLARE
fminsi int;
DECLARE
fmaxsr int;
DECLARE
favgsr int;
DECLARE
fminsr int;
DECLARE
fmaxst int;
DECLARE
favgst int;
DECLARE
fminst int;
DECLARE
fmaxsp int;
DECLARE
favgsp int;
DECLARE
fminsp int;
select f_area_id
into fareaid
from t_probe
WHERE f_id = fprobeid;
select sum(f_danger_times),
       max(f_max_svd),
       avg(f_avg_svd),
       min(f_min_svd),
       max(f_max_sv),
       avg(f_avg_sv),
       min(f_min_sv),
       max(f_max_si),
       avg(f_avg_si),
       min(f_min_si),
       max(f_max_sr),
       avg(f_avg_sr),
       min(f_min_sr),
       max(f_max_st),
       avg(f_avg_st),
       min(f_min_st),
       max(f_max_sp),
       avg(f_avg_sp),
       min(f_min_sp)
into
    fdangertimes,
    fmaxsvd,
    favgsvd,
    fminsvd,
    fmaxsv,
    favgsv,
    fminsv,
    fmaxsi,
    favgsi,
    fminsi,
    fmaxsr,
    favgsr,
    fminsr,
    fmaxst,
    favgst,
    fminst,
    fmaxsp,
    favgsp,
    fminsp
from dws_device_danger_day
         INNER JOIN t_probe on t_probe.f_id = dws_device_danger_day.f_probe_id
where t_probe.f_area_id = fareaid
  and DATE_FORMAT(fday, "%Y-%m-%d") = DATE_FORMAT(f_day, "%Y-%m-%d");
delete
from dws_area_danger_day
where f_area_id = fareaid
  and DATE_FORMAT(fday, "%Y-%m-%d") = DATE_FORMAT(f_day, "%Y-%m-%d");
INSERT INTO dws_area_danger_day (f_area_id,
                                 f_day,
                                 f_danger_times,
                                 f_max_svd,
                                 f_avg_svd,
                                 f_min_svd,
                                 f_max_sv,
                                 f_avg_sv,
                                 f_min_sv,
                                 f_max_si,
                                 f_avg_si,
                                 f_min_si,
                                 f_max_sr,
                                 f_avg_sr,
                                 f_min_sr,
                                 f_max_st,
                                 f_avg_st,
                                 f_min_st,
                                 f_max_sp,
                                 f_avg_sp,
                                 f_min_sp)
VALUES (fareaid,
        DATE_FORMAT(fday, "%Y-%m-%d"),
        fdangertimes,
        fmaxsvd,
        favgsvd,
        fminsvd,
        fmaxsv,
        favgsv,
        fminsv,
        fmaxsi,
        favgsi,
        fminsi,
        fmaxsr,
        favgsr,
        fminsr,
        fmaxst,
        favgst,
        fminst,
        fmaxsp,
        favgsp,
        fminsp);
end;

