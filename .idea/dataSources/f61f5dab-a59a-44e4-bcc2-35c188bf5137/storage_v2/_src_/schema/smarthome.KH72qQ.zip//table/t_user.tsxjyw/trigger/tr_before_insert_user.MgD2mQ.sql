create definer = root@localhost trigger tr_before_insert_user
    before insert
    on t_user
    for each row
trig:BEGIN
    
    SET NEW.f_guid = func_gen_user_guid(NEW.f_username, 'U', NEW.f_customer_id);
    
END;

