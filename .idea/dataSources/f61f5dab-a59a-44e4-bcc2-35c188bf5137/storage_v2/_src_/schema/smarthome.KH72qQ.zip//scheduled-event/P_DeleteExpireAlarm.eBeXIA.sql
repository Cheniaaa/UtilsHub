create definer = root@localhost event P_DeleteExpireAlarm on schedule
    every '1' DAY
        starts '2020-12-29 00:20:00'
    enable
    do
    delete from `报警纪录` where `报警时刻`< DATE_ADD(now(), INTERVAL -6 month );

