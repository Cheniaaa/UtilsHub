create definer = root@localhost view v_control_group_target as
select `smarthome`.`t_control_group_target`.`f_control_group_id`   AS `f_control_group_id`,
       `smarthome`.`t_area`.`f_id`                                 AS `f_area_id`,
       `smarthome`.`t_area`.`f_organ_id`                           AS `f_organ_id`,
       `smarthome`.`t_area`.`f_path`                               AS `f_path`,
       `smarthome`.`t_control_group_target`.`f_target_category_id` AS `f_target_category_id`
from (`smarthome`.`t_control_group_target` join `smarthome`.`t_area`
      on ((`smarthome`.`t_control_group_target`.`f_area_id` = `smarthome`.`t_area`.`f_id`)));

-- comment on column v_control_group_target.f_control_group_id not supported: 控制组ID

-- comment on column v_control_group_target.f_area_id not supported: 区域ID

-- comment on column v_control_group_target.f_organ_id not supported: 所属网点ID

-- comment on column v_control_group_target.f_path not supported: 区域绝对路径 以->分割的各级名称

-- comment on column v_control_group_target.f_target_category_id not supported: 对象类型ID 0=任何类型

