create
    definer = root@`%` procedure p_refresh_area_danger_year(IN fareaid int, IN fday datetime)
begin
DECLARE
fdangertimes int;
DECLARE
fmaxsvd int;
DECLARE
favgsvd int;
DECLARE
fminsvd int;
DECLARE
fmaxsv int;
DECLARE
favgsv int;
DECLARE
fminsv int;
DECLARE
fmaxsi int;
DECLARE
favgsi int;
DECLARE
fminsi int;
DECLARE
fmaxsr int;
DECLARE
favgsr int;
DECLARE
fminsr int;
DECLARE
fmaxst int;
DECLARE
favgst int;
DECLARE
fminst int;
DECLARE
fmaxsp int;
DECLARE
favgsp int;
DECLARE
fminsp int;
select sum(f_danger_times),
       max(f_max_svd),
       avg(f_avg_svd),
       min(f_min_svd),
       max(f_max_sv),
       avg(f_avg_sv),
       min(f_min_sv),
       max(f_max_si),
       avg(f_avg_si),
       min(f_min_si),
       max(f_max_sr),
       avg(f_avg_sr),
       min(f_min_sr),
       max(f_max_st),
       avg(f_avg_st),
       min(f_min_st),
       max(f_max_sp),
       avg(f_avg_sp),
       min(f_min_sp)
into
    fdangertimes ,
    fmaxsvd ,
    favgsvd,
    fminsvd,
    fmaxsv,
    favgsv,
    fminsv,
    fmaxsi,
    favgsi,
    fminsi,
    fmaxsr,
    favgsr,
    fminsr,
    fmaxst,
    favgst,
    fminst,
    fmaxsp,
    favgsp,
    fminsp
from dws_area_danger_day
where f_area_id = fareaid and year (fday) = year ( f_day);
delete
from dws_area_danger_year
where f_area_id = fareaid and year (f_year_startday) = year ( fday);
INSERT INTO dws_area_danger_year (f_area_id,
                                  f_year_startday,
                                  f_danger_times,
                                  f_max_svd,
                                  f_avg_svd,
                                  f_min_svd,
                                  f_max_sv,
                                  f_avg_sv,
                                  f_min_sv,
                                  f_max_si,
                                  f_avg_si,
                                  f_min_si,
                                  f_max_sr,
                                  f_min_sr,
                                  f_avg_sr,
                                  f_max_st,
                                  f_avg_st,
                                  f_min_st,
                                  f_max_sp,
                                  f_avg_sp,
                                  f_min_sp)
VALUES (fareaid,
        DATE_SUB(fday, INTERVAL DAYOFYEAR(fday)-1 DAY),
        fdangertimes,
        fmaxsvd,
        favgsvd,
        fminsvd,
        fmaxsv,
        favgsv,
        fminsv,
        fmaxsi,
        favgsi,
        fminsi,
        fmaxsr,
        favgsr,
        fminsr,
        fmaxst,
        favgst,
        fminst,
        fmaxsp,
        favgsp,
        fminsp);
end;

