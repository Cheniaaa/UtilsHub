create
    definer = root@`%` procedure p_initial_area_consum_none()
BEGIN
-- 定义将插入到新表中数据的变量
DECLARE fuserid int;
DECLARE fprobeid int;
DECLARE fday datetime;

DECLARE done INT DEFAULT 0;
DECLARE cur1 CURSOR FOR
SELECT distinct f_user_id,f_probe_id,f_start_time FROM t_battery_log;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=1;
OPEN cur1;
emp_loop:LOOP
FETCH cur1 INTO fuserid,fprobeid,fday;
IF done=1 THEN
	LEAVE emp_loop;
END IF;
call p_refresh_battery_day(fuserid,fprobeid,fday );
call p_refresh_battery_user_day(fuserid,fprobeid,fday );
call p_refresh_battery_probe_day(fuserid,fprobeid,fday );
call p_refresh_battery_user_week(fuserid,fprobeid,fday );
call p_refresh_battery_probe_week(fuserid,fprobeid,fday );
call p_refresh_battery_user_month(fuserid,fprobeid,fday );
call p_refresh_battery_probe_month(fuserid,fprobeid,fday );
call p_refresh_battery_user_year(fuserid,fprobeid,fday );
call p_refresh_battery_probe_year(fuserid,fprobeid,fday );
call p_refresh_battery_user_total(fuserid,fprobeid,fday );
call p_refresh_battery_probe_total(fuserid,fprobeid,fday );
END LOOP emp_loop;
cLose cur1;

END;

