create definer = root@localhost view v_organ as
select `smarthome`.`t_organ`.`f_id`                       AS `f_id`,
       `smarthome`.`t_organ`.`f_customer_id`              AS `f_customer_id`,
       `smarthome`.`t_organ`.`f_name`                     AS `f_name`,
       `smarthome`.`t_organ`.`f_installed_host_quantity`  AS `f_installed_host_quantity`,
       `smarthome`.`t_organ`.`f_installed_probe_quantity` AS `f_installed_probe_quantity`,
       `smarthome`.`t_organ`.`f_town_code`                AS `f_town_code`,
       `smarthome`.`t_organ`.`f_address`                  AS `f_address`,
       `smarthome`.`t_organ`.`f_longitude`                AS `f_longitude`,
       `smarthome`.`t_organ`.`f_latitude`                 AS `f_latitude`,
       `smarthome`.`t_organ`.`f_creator_id`               AS `f_creator_id`,
       `smarthome`.`t_organ`.`f_creation_time`            AS `f_creation_time`,
       `smarthome`.`t_organ`.`f_updated_time`             AS `f_updated_time`,
       `smarthome`.`t_organ`.`f_enable_line_loss`         AS `f_enable_line_loss`,
       `smarthome`.`t_organ`.`f_recover_max_num`          AS `f_recover_max_num`,
       `smarthome`.`dict_town`.`f_name`                   AS `f_town_name`,
       `smarthome`.`dict_county`.`f_name`                 AS `f_county_name`,
       `smarthome`.`dict_city`.`f_name`                   AS `f_city_name`,
       `smarthome`.`dict_province`.`f_name`               AS `f_province_name`
from ((((`smarthome`.`t_organ` join `smarthome`.`dict_town`
         on ((`smarthome`.`t_organ`.`f_town_code` = `smarthome`.`dict_town`.`f_code`))) join `smarthome`.`dict_county`
        on ((`smarthome`.`dict_town`.`f_county_code` =
             `smarthome`.`dict_county`.`f_code`))) join `smarthome`.`dict_city`
       on ((`smarthome`.`dict_county`.`f_city_code` =
            `smarthome`.`dict_city`.`f_code`))) join `smarthome`.`dict_province`
      on ((`smarthome`.`dict_city`.`f_province_code` = `smarthome`.`dict_province`.`f_code`)));

-- comment on column v_organ.f_id not supported: ID

-- comment on column v_organ.f_customer_id not supported: 客户公司ID

-- comment on column v_organ.f_name not supported: 名称

-- comment on column v_organ.f_installed_host_quantity not supported: 已装主机设备数

-- comment on column v_organ.f_installed_probe_quantity not supported: 已装探头数

-- comment on column v_organ.f_town_code not supported: 所在乡镇街道

-- comment on column v_organ.f_address not supported: 详细地址

-- comment on column v_organ.f_longitude not supported: 经度

-- comment on column v_organ.f_latitude not supported: 纬度

-- comment on column v_organ.f_creator_id not supported: 创建者ID

-- comment on column v_organ.f_creation_time not supported: 创建时间

-- comment on column v_organ.f_updated_time not supported: 更新时间

-- comment on column v_organ.f_enable_line_loss not supported: 开启线损

-- comment on column v_organ.f_recover_max_num not supported: 失联探活最大次数

-- comment on column v_organ.f_town_name not supported: 名称

-- comment on column v_organ.f_county_name not supported: 名称

-- comment on column v_organ.f_city_name not supported: 名称

-- comment on column v_organ.f_province_name not supported: 名称

