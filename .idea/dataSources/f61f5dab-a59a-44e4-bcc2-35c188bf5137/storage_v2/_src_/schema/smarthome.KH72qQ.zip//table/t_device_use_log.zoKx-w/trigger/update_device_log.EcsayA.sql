create definer = root@`%` trigger update_device_log
    after update
    on t_device_use_log
    for each row
BEGIN
    DECLARE fchannel int;
DECLARE fprobeid int;
DECLARE fday datetime;
DECLARE fareaid int;
DECLARE fdevicetypeid int;
SET fchannel =NEW.f_probe_channel;
SET fprobeid = NEW.f_probe_id;
SET fday = DATE_FORMAT(NEW.f_start_time,'%Y-%m-%d 00:00:00');
    select f_area_id, f_probe_kind_code into fareaid,fdevicetypeid from t_probe WHERE f_id = fprobeid;
    call p_refresh_device_day(fprobeid,fchannel,fday);
    call p_refresh_device_week(fprobeid,fchannel,fday);
    call p_refresh_device_month(fprobeid,fchannel,fday);
    call p_refresh_device_year(fprobeid,fchannel,fday);
    call p_refresh_device_total(fprobeid,fchannel,fday);
    call p_refresh_area_consum_day(fareaid ,fday);
    call p_refresh_area_consum_week(fareaid ,fday);
    call p_refresh_area_consum_month(fareaid ,fday);
    call p_refresh_area_consum_year(fareaid ,fday);
    call p_refresh_area_consum_total(fareaid ,fday);
    call p_refresh_area_consum_7day(fareaid ,fday);
    call p_refresh_area_devicetype_day(fareaid,fdevicetypeid ,fday);
END;

