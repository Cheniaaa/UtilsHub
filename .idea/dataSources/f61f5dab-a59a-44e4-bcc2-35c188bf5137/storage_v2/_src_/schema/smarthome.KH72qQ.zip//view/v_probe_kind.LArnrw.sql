create definer = root@localhost view v_probe_kind as
select `smarthome`.`dict_probe_kind`.`f_probe_category_code` AS `f_probe_category_code`,
       `smarthome`.`dict_probe_kind`.`f_channel_num`         AS `f_channel_num`,
       `smarthome`.`dict_icon`.`f_url`                       AS `f_url`,
       `smarthome`.`dict_probe_kind`.`f_code`                AS `f_code`,
       `smarthome`.`dict_probe_kind`.`f_enabled`             AS `f_enabled`,
       `smarthome`.`dict_probe_kind`.`f_name`                AS `f_name`
from ((`smarthome`.`dict_probe_kind_icon` join `smarthome`.`dict_probe_kind`
       on ((`smarthome`.`dict_probe_kind`.`f_code` =
            `smarthome`.`dict_probe_kind_icon`.`f_probe_kind_id`))) join `smarthome`.`dict_icon`
      on ((`smarthome`.`dict_probe_kind_icon`.`f_icon_id` = `smarthome`.`dict_icon`.`f_id`)));

-- comment on column v_probe_kind.f_probe_category_code not supported: 类型编码

-- comment on column v_probe_kind.f_channel_num not supported: 通道数

-- comment on column v_probe_kind.f_url not supported: 图标URL

-- comment on column v_probe_kind.f_code not supported: 子类别编号

-- comment on column v_probe_kind.f_enabled not supported: 是否可用

-- comment on column v_probe_kind.f_name not supported: 名称

