create
    definer = root@localhost procedure p_insert_test_data()
BEGIN
    DECLARE var_sql VARCHAR(1024);
    DECLARE var_done INT DEFAULT 0;
    DECLARE var_warning INT DEFAULT 0; 
    
	declare var_probe_id int;
	declare var_cusp_electric_quantity decimal(8,2);
	declare var_peak_electric_quantity decimal(8,2);
	declare var_flat_electric_quantity decimal(8,2);
	declare var_valley_electric_quantity decimal(8,2);
	declare var_phase_a_voltage decimal(8,2);
	declare var_phase_b_voltage decimal(8,2);
	declare var_phase_c_voltage decimal(8,2);
	declare var_phase_a_current decimal(8,2);
	declare var_phase_b_current decimal(8,2);
	declare var_phase_c_current decimal(8,2);
	declare var_zero_line_current decimal(8,2);
	declare var_phase_a_power decimal(8,2);
	declare var_phase_b_power decimal(8,2);
	declare var_phase_c_power decimal(8,2);
	declare var_report_way tinyint;
	
	declare i int default 1;
	
	START TRANSACTION;
	WHILE i <= 200000000 DO -- 循环开始
		set var_probe_id = 2 + RAND()*100;
		set var_cusp_electric_quantity = 10 + RAND()*6-3;
		set var_peak_electric_quantity = 8.24 + RAND()*6-3;
		set var_flat_electric_quantity = 12.46 + RAND()*6-3;
		set var_valley_electric_quantity = 5.32 + RAND()*6-3;
		set var_phase_a_voltage = 220.90 + RAND()*6-3;
		set var_phase_b_voltage = 1666.50 + RAND()*6-3;
		set var_phase_c_voltage = 7 + RAND()*6-3;
		set var_phase_a_current = 8.20 + RAND()*6-3;
		set var_phase_b_current = 7 + RAND()*6-3;
		set var_phase_c_current = 7 + RAND()*6-3;
		set var_zero_line_current = 8.12 + RAND()*6-3;
		set var_phase_a_power = 8.32 + RAND()*6-3;
		set var_phase_b_power = 8 + RAND()*6-3;
		set var_phase_c_power = 9 + RAND()*6-3;
		set var_report_way = 2 + RAND()*2-1;

	
        insert into t_electricity_meter_data 
			(f_probe_id, f_cusp_electric_quantity, f_peak_electric_quantity, f_flat_electric_quantity, f_valley_electric_quantity, 
			f_phase_a_voltage, f_phase_b_voltage, f_phase_c_voltage, f_phase_a_current, f_phase_b_current, f_phase_c_current, f_zero_line_current, 
			f_phase_a_power, f_phase_b_power, f_phase_c_power, f_report_way, f_creation_time) 
		values (var_probe_id, var_cusp_electric_quantity, var_peak_electric_quantity, var_flat_electric_quantity, var_valley_electric_quantity, 
			var_phase_a_voltage, var_phase_b_voltage, var_phase_c_voltage, var_phase_a_current, var_phase_b_current, var_phase_c_current, var_zero_line_current, 
			var_phase_a_power, var_phase_b_power, var_phase_c_power, var_report_way,now());
		
		
		set i=i+1;	

		IF i % 20001 = 0 THEN
			COMMIT;
			START TRANSACTION;
		END IF;
    end while; -- 循环结束
	COMMIT;
END;

