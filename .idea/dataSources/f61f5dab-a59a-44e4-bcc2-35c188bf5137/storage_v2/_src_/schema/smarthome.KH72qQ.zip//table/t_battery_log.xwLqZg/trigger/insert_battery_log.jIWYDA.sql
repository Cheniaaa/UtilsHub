create definer = root@`%` trigger insert_battery_log
    after insert
    on t_battery_log
    for each row
BEGIN
-- 定义将插入到新表中数据的变量
DECLARE fuserid int;
DECLARE fprobeid int;
DECLARE fday datetime;


SET fuserid =NEW.f_user_id;
SET fprobeid = NEW.f_probe_id;
SET fday = NEW.f_start_time ;
-- 
call p_refresh_battery_day(fuserid,fprobeid,fday );
call p_refresh_battery_user_day(fuserid,fprobeid,fday );
call p_refresh_battery_probe_day(fuserid,fprobeid,fday );
call p_refresh_battery_user_week(fuserid,fprobeid,fday );
call p_refresh_battery_probe_week(fuserid,fprobeid,fday );
call p_refresh_battery_user_month(fuserid,fprobeid,fday );
call p_refresh_battery_probe_month(fuserid,fprobeid,fday );
call p_refresh_battery_user_year(fuserid,fprobeid,fday );
call p_refresh_battery_probe_year(fuserid,fprobeid,fday );
call p_refresh_battery_user_total(fuserid,fprobeid,fday );
call p_refresh_battery_probe_total(fuserid,fprobeid,fday );
END;

