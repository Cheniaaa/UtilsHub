create
    definer = root@`%` procedure p_refresh_area_consum_total(IN fareaid int, IN fday datetime)
begin
DECLARE
fusetimes int;
DECLARE
fuseduration int;
DECLARE
fsqv bigint;
DECLARE
fmaxsv int;
DECLARE
favgsv int;
DECLARE
fminsv int;
DECLARE
fmaxsi int;
DECLARE
favgsi int;
DECLARE
fminsi int;
DECLARE
fmaxsr int;
DECLARE
favgsr int;
DECLARE
fminsr int;
DECLARE
fmaxst int;
DECLARE
favgst int;
DECLARE
fminst int;
DECLARE
fmaxsp int;
DECLARE
favgsp int;
DECLARE
fminsp int;
select sum(f_use_times),
       sum(f_use_duration),
       sum(f_sqv),
       max(f_max_sv),
       avg(f_avg_sv),
       min(f_min_sv),
       max(f_max_si),
       avg(f_avg_si),
       min(f_min_si),
       max(f_max_sr),
       avg(f_avg_sr),
       min(f_min_sr),
       max(f_max_st),
       avg(f_avg_st),
       min(f_min_st),
       max(f_max_sp),
       avg(f_avg_sp),
       min(f_min_sp)
into
    fusetimes ,
    fuseduration ,
    fsqv,
    fmaxsv,
    favgsv,
    fminsv,
    fmaxsi,
    favgsi,
    fminsi,
    fmaxsr,
    favgsr,
    fminsr,
    fmaxst,
    favgst,
    fminst,
    fmaxsp,
    favgsp,
    fminsp
from dws_area_consum_day
where f_area_id = fareaid;
delete
from dws_area_consum_total
where f_area_id = fareaid;
INSERT INTO dws_area_consum_total (f_area_id,
                                   f_use_times,
                                   f_use_duration,
                                   f_sqv,
                                   f_max_sv,
                                   f_avg_sv,
                                   f_min_sv,
                                   f_max_si,
                                   f_avg_si,
                                   f_min_si,
                                   f_max_sr,
                                   f_min_sr,
                                   f_avg_sr,
                                   f_max_st,
                                   f_avg_st,
                                   f_min_st,
                                   f_max_sp,
                                   f_avg_sp,
                                   f_min_sp)
VALUES (fareaid,
        fusetimes,
        fuseduration,
        fsqv,
        fmaxsv,
        favgsv,
        fminsv,
        fmaxsi,
        favgsi,
        fminsi,
        fmaxsr,
        favgsr,
        fminsr,
        fmaxst,
        favgst,
        fminst,
        fmaxsp,
        favgsp,
        fminsp);
end;

