create
    definer = root@localhost procedure p_refresh_battery_user_week(IN fuserid int, IN fprobeid int, IN fday datetime)
begin
    DECLARE fchargetimes int;
    DECLARE fchargeduration int;
    DECLARE fsqv bigint;
    DECLARE fmaxsv int;
    DECLARE favgsv int;
    DECLARE fminsv int;
    DECLARE fmaxsi int;
    DECLARE favgsi int;
    DECLARE fminsi int;
    DECLARE fmaxsr int;
    DECLARE favgsr int;
    DECLARE fminsr int;
    DECLARE fmaxst int;
    DECLARE favgst int;
    DECLARE fminst int;
    DECLARE fmaxsp int;
    DECLARE favgsp int;
    DECLARE fminsp int;
    select
        sum(f_charge_times),
        sum(f_charge_duration),
        sum(f_sqv),
        max(f_max_sv),
        avg(f_avg_sv),
        min(f_min_sv),
        max(f_max_si),
        avg(f_avg_si),
        min(f_min_si),
        max(f_max_sr),
        avg(f_avg_sr),
        min(f_min_sr),
        max(f_max_st),
        avg(f_avg_st),
        min(f_min_st),
        max(f_max_sp),
        avg(f_avg_sp),
        min(f_min_sp)
    into
        fchargetimes ,
        fchargeduration ,
        fsqv,
        fmaxsv,
        favgsv,
        fminsv,
        fmaxsi,
        favgsi,
        fminsi,
        fmaxsr,
        favgsr,
        fminsr,
        fmaxst,
        favgst,
        fminst,
        fmaxsp,
        favgsp,
        fminsp
    from dws_battery_user_day
    where f_user_id = fuserid and yearweek(fday,1) =yearweek( f_day,1) ;
    delete from dws_battery_user_week where f_user_id = fuserid and yearweek(fday,1) =yearweek( f_week_start_day,1) ;
    INSERT INTO dws_battery_user_week (
        f_user_id,
        f_week_start_day,
        f_charge_times,
        f_charge_duration,
        f_sqv,
        f_max_sv,
        f_avg_sv,
        f_min_sv,
        f_max_si,
        f_avg_si,
        f_min_si,
        f_max_sr,
        f_min_sr,
        f_avg_sr,
        f_max_st,
        f_avg_st,
        f_min_st,
        f_max_sp,
        f_avg_sp,
        f_min_sp
    )
    VALUES
    (
        fuserid,
        DATE_SUB(fday,INTERVAL DAYOFWEEK(fday)-1 DAY),
        fchargetimes ,
        fchargeduration ,
        fsqv,
        fmaxsv,
        favgsv,
        fminsv,
        fmaxsi,
        favgsi,
        fminsi,
        fmaxsr,
        favgsr,
        fminsr,
        fmaxst,
        favgst,
        fminst,
        fmaxsp,
        favgsp,
        fminsp);
end;

