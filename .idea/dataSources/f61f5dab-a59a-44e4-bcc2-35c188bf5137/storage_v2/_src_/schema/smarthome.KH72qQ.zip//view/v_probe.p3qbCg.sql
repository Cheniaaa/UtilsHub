create definer = root@localhost view v_probe as
select `smarthome`.`t_probe`.`f_id`                          AS `f_id`,
       `smarthome`.`t_probe`.`f_host_id`                     AS `f_host_id`,
       `smarthome`.`t_probe`.`f_area_id`                     AS `f_area_id`,
       `smarthome`.`t_probe`.`f_defense_area`                AS `f_defense_area`,
       `smarthome`.`t_probe`.`f_probe_mold_code`             AS `f_probe_mold_code`,
       `smarthome`.`t_probe`.`f_channel_state`               AS `f_channel_state`,
       `smarthome`.`t_probe`.`f_name`                        AS `f_name`,
       `smarthome`.`t_probe`.`f_status`                      AS `f_status`,
       `smarthome`.`t_probe`.`f_creator_id`                  AS `f_creator_id`,
       `smarthome`.`t_probe`.`f_creation_time`               AS `f_creation_time`,
       `smarthome`.`t_probe`.`f_last_online_time`            AS `f_last_online_time`,
       `smarthome`.`t_probe`.`f_location_desc`               AS `f_location_desc`,
       `smarthome`.`t_probe`.`f_desc`                        AS `f_desc`,
       `smarthome`.`dict_probe_kind`.`f_probe_category_code` AS `f_probe_category_code`,
       `smarthome`.`dict_probe_kind`.`f_channel_num`         AS `f_channel_num`,
       `smarthome`.`dict_probe_mold`.`f_probe_kind_code`     AS `f_probe_kind_code`,
       `smarthome`.`dict_probe_kind`.`f_name`                AS `f_probe_kind_name`
from ((`smarthome`.`t_probe` join `smarthome`.`dict_probe_mold`
       on (((`smarthome`.`t_probe`.`f_probe_mold_code` = `smarthome`.`dict_probe_mold`.`f_code`) and
            (`smarthome`.`t_probe`.`f_probe_kind_code` =
             `smarthome`.`dict_probe_mold`.`f_probe_kind_code`)))) join `smarthome`.`dict_probe_kind`
      on ((`smarthome`.`t_probe`.`f_probe_kind_code` = `smarthome`.`dict_probe_kind`.`f_code`)));

-- comment on column v_probe.f_id not supported: ID

-- comment on column v_probe.f_host_id not supported: 所属设备ID

-- comment on column v_probe.f_area_id not supported: 所置区域id

-- comment on column v_probe.f_defense_area not supported: 接设备防区

-- comment on column v_probe.f_probe_mold_code not supported: 探头细类号

-- comment on column v_probe.f_channel_state not supported: 通道状态 用位表示对应通道的开关

-- comment on column v_probe.f_name not supported: 名称

-- comment on column v_probe.f_status not supported: 状态 0=初装,O=在线,F=离线

-- comment on column v_probe.f_creator_id not supported: 创建者ID

-- comment on column v_probe.f_creation_time not supported: 创建时间

-- comment on column v_probe.f_last_online_time not supported: 最后在线间

-- comment on column v_probe.f_location_desc not supported: 放置位置说明

-- comment on column v_probe.f_desc not supported: 备注

-- comment on column v_probe.f_probe_category_code not supported: 类型编码

-- comment on column v_probe.f_channel_num not supported: 通道数

-- comment on column v_probe.f_probe_kind_code not supported: 子类型码

-- comment on column v_probe.f_probe_kind_name not supported: 名称

