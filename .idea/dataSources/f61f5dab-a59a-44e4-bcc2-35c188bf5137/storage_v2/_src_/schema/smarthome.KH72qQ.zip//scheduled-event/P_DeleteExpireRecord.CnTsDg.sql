create definer = root@localhost event P_DeleteExpireRecord on schedule
    every '1' DAY
        starts '2020-12-29 00:20:00'
    enable
    do
    delete from `T_EvProcRecord` where `EvProc_time`< DATE_ADD(now(), INTERVAL -6 month );

