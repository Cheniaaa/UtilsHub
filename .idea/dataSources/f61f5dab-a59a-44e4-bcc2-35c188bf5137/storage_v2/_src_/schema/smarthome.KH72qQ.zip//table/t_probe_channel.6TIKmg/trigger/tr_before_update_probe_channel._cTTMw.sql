create definer = root@localhost trigger tr_before_update_probe_channel
    before update
    on t_probe_channel
    for each row
trig:BEGIN
    
    DECLARE var_timepoint datetime;
    DECLARE var_minutes int;
    DECLARE var_existed tinyint;        -- 已插入过统计值
    DECLARE var_on_times tinyint;
    DECLARE var_off_times tinyint;
    
    SET var_existed = 0;
    SET var_minutes = 60;
    SET var_timepoint = fn_minute_floor(now(), var_minutes);
    
    SELECT 1 INTO var_existed FROM t_target_time_and_times_statistics_1h WHERE f_probe_id=NEW.f_probe_id AND f_channel=NEW.f_channel AND f_date_time=var_timepoint;
    
    IF fn_is_channel_on(NEW.f_state) AND NOT fn_is_channel_on(OLD.f_state) THEN             -- 开
        IF var_existed = 1 THEN
            UPDATE t_target_time_and_times_statistics_1h SET f_on_times = f_on_times + 1 
                WHERE f_probe_id=NEW.f_probe_id AND f_channel=NEW.f_channel AND f_date_time=var_timepoint;
        ELSE
            INSERT INTO t_target_time_and_times_statistics_1h (f_probe_id, f_channel, f_date_time, f_target_category_id, f_on_times)
                VALUES (NEW.f_probe_id, NEW.f_channel, var_timepoint, NEW.f_target_category_id, 1);
        END IF;
        
        SET NEW.f_on_off_time = now();
    ELSEIF NOT fn_is_channel_on(NEW.f_state) AND fn_is_channel_on(OLD.f_state) THEN         -- 关
        IF var_existed = 1 THEN
            UPDATE t_target_time_and_times_statistics_1h SET f_off_times = f_off_times + 1
                WHERE f_probe_id=NEW.f_probe_id AND f_channel=NEW.f_channel AND f_date_time=var_timepoint;
        ELSE
            INSERT INTO t_target_time_and_times_statistics_1h (f_probe_id, f_channel, f_date_time, f_target_category_id, f_off_times)
                VALUES (NEW.f_probe_id, NEW.f_channel, var_timepoint, NEW.f_target_category_id, 1);
        END IF;
        
        SET NEW.f_on_off_time = now();
    END IF;
    
END;

