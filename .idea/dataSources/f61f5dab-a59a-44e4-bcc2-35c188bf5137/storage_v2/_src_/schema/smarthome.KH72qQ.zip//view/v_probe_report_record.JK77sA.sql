create definer = root@localhost view v_probe_report_record as
select `smarthome`.`t_probe_report_record`.`f_id`             AS `f_id`,
       `smarthome`.`t_probe_report_record`.`f_probe_id`       AS `f_probe_id`,
       `smarthome`.`t_probe_report_record`.`f_channel`        AS `f_channel`,
       `smarthome`.`t_probe_report_record`.`f_on_off`         AS `f_on_off`,
       `smarthome`.`t_probe_report_record`.`f_mode`           AS `f_mode`,
       `smarthome`.`t_probe_report_record`.`f_temperature`    AS `f_temperature`,
       `smarthome`.`t_probe_report_record`.`f_wind_speed`     AS `f_wind_speed`,
       `smarthome`.`t_probe_report_record`.`f_wind_direction` AS `f_wind_direction`,
       `smarthome`.`t_probe_report_record`.`f_updated_time`   AS `f_updated_time`,
       `smarthome`.`t_probe_channel`.`f_name`                 AS `f_name`,
       `smarthome`.`dict_probe_kind`.`f_name`                 AS `f_probe_kind_name`,
       `smarthome`.`t_area`.`f_path`                          AS `f_path`
from (((((`smarthome`.`t_probe_report_record` join `smarthome`.`t_probe_channel`
          on (((`smarthome`.`t_probe_report_record`.`f_probe_id` = `smarthome`.`t_probe_channel`.`f_probe_id`) and
               (`smarthome`.`t_probe_report_record`.`f_channel` =
                `smarthome`.`t_probe_channel`.`f_channel`)))) join `smarthome`.`t_probe`
         on ((`smarthome`.`t_probe_channel`.`f_probe_id` =
              `smarthome`.`t_probe`.`f_id`))) join `smarthome`.`dict_probe_mold`
        on ((`smarthome`.`t_probe`.`f_probe_mold_code` =
             `smarthome`.`dict_probe_mold`.`f_code`))) join `smarthome`.`dict_probe_kind`
       on ((`smarthome`.`dict_probe_mold`.`f_probe_kind_code` =
            `smarthome`.`dict_probe_kind`.`f_code`))) join `smarthome`.`t_area`
      on ((`smarthome`.`t_probe`.`f_area_id` = `smarthome`.`t_area`.`f_id`)));

-- comment on column v_probe_report_record.f_id not supported: ID

-- comment on column v_probe_report_record.f_probe_id not supported: 控制板探头ID

-- comment on column v_probe_report_record.f_channel not supported: 通道

-- comment on column v_probe_report_record.f_on_off not supported: 开关 0=关闭,1=打开,3=启用,4=禁用,127=无效

-- comment on column v_probe_report_record.f_mode not supported: 设置模式 0=自动,1=制冷,2=除湿,3=送风,4=制暖,127=无效

-- comment on column v_probe_report_record.f_temperature not supported: 设置温度 16~31=温度值,127=无效

-- comment on column v_probe_report_record.f_wind_speed not supported: 设置风速 0=自动,1~3档位,127=无效

-- comment on column v_probe_report_record.f_wind_direction not supported: 设置风向 0=自动摆风,1=手动摆风,127=无效

-- comment on column v_probe_report_record.f_updated_time not supported: 上报时间

-- comment on column v_probe_report_record.f_name not supported: 名称

-- comment on column v_probe_report_record.f_probe_kind_name not supported: 名称

-- comment on column v_probe_report_record.f_path not supported: 区域绝对路径 以->分割的各级名称

