create
    definer = root@localhost procedure p_debug(IN var_msg varchar(1024), IN var_clear tinyint(1))
BEGIN
    IF var_clear=true THEN
        DELETE FROM temp_debug;
    END IF;
    INSERT INTO temp_debug VALUES (var_msg);
END;

