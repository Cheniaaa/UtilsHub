create definer = root@`%` trigger insert_danger_log
    after insert
    on t_device_danger_log
    for each row
BEGIN
    DECLARE fchannel int;
DECLARE fprobeid int;
DECLARE fday datetime;
DECLARE fareaid int;
SET fchannel =NEW.f_probe_channel;
SET fprobeid = NEW.f_probe_id;
SET fday = DATE_FORMAT(NEW.f_create_time,'%Y-%m-%d 00:00:00') ;
    select f_area_id into fareaid from t_probe WHERE f_id = fprobeid;
    call p_refresh_device_danger_day(fprobeid,fchannel,fday);
    call p_refresh_device_danger_week(fprobeid,fchannel,fday);
    call p_refresh_device_danger_month(fprobeid,fchannel,fday);
    call p_refresh_device_danger_year(fprobeid,fchannel,fday);
    call p_refresh_device_danger_total(fprobeid,fchannel,fday);
    call p_refresh_area_danger_day(fprobeid,fchannel,fday);
    call p_refresh_area_danger_week(fareaid ,fday);
    call p_refresh_area_danger_month(fareaid ,fday);
    call p_refresh_area_danger_year(fareaid ,fday);
    call p_refresh_area_danger_total(fareaid ,fday);
END;

