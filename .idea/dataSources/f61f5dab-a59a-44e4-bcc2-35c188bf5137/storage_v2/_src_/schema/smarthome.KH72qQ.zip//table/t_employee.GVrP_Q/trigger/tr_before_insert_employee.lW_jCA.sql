create definer = root@localhost trigger tr_before_insert_employee
    before insert
    on t_employee
    for each row
trig:BEGIN

    

    SET NEW.f_guid = func_gen_user_guid(NEW.f_username, 'E', NEW.f_partnership_code);

    

END;

