create
    definer = root@`%` procedure p_refresh_device_danger_day(IN fprobeid int, IN fchannel int, IN fday datetime)
begin
DECLARE
fdangertimes int;
DECLARE
fmaxsvd int;
DECLARE
favgsvd int;
DECLARE
fminsvd int;
DECLARE
fmaxsv int;
DECLARE
favgsv int;
DECLARE
fminsv int;
DECLARE
fmaxsi int;
DECLARE
favgsi int;
DECLARE
fminsi int;
DECLARE
fmaxsr int;
DECLARE
favgsr int;
DECLARE
fminsr int;
DECLARE
fmaxst int;
DECLARE
favgst int;
DECLARE
fminst int;
DECLARE
fmaxsp int;
DECLARE
favgsp int;
DECLARE
fminsp int;
select count(*),
       max(f_svd),
       avg(f_svd),
       min(f_svd),
       max(f_sv),
       avg(f_sv),
       min(f_sv),
       max(f_si),
       avg(f_si),
       min(f_si),
       max(f_sr),
       avg(f_sr),
       min(f_sr),
       max(f_st),
       avg(f_st),
       min(f_st),
       max(f_sp),
       avg(f_sp),
       min(f_sp)
into
    fdangertimes,
    fmaxsvd,
    favgsvd,
    fminsvd,
    fmaxsv,
    favgsv,
    fminsv,
    fmaxsi,
    favgsi,
    fminsi,
    fmaxsr,
    favgsr,
    fminsr,
    fmaxst,
    favgst,
    fminst,
    fmaxsp,
    favgsp,
    fminsp
from t_device_danger_log
where f_probe_channel = fchannel
  and f_probe_id = fprobeid
  and DATE_FORMAT(fday, "%Y-%m-%d") = DATE_FORMAT(f_create_time, "%Y-%m-%d");
delete
from dws_device_danger_day
where f_probe_channel = fchannel
  and f_probe_id = fprobeid
  and DATE_FORMAT(fday, "%Y-%m-%d") = DATE_FORMAT(f_day, "%Y-%m-%d");
INSERT INTO dws_device_danger_day (f_probe_id,
                                   f_probe_channel,
                                   f_day,
                                   f_danger_times,
                                   f_max_svd,
                                   f_avg_svd,
                                   f_min_svd,
                                   f_max_sv,
                                   f_avg_sv,
                                   f_min_sv,
                                   f_max_si,
                                   f_avg_si,
                                   f_min_si,
                                   f_max_sr,
                                   f_min_sr,
                                   f_avg_sr,
                                   f_max_st,
                                   f_avg_st,
                                   f_min_st,
                                   f_max_sp,
                                   f_avg_sp,
                                   f_min_sp)
VALUES (fprobeid,
        fchannel,
        DATE_FORMAT(fday, "%Y-%m-%d"),
        fdangertimes,
        fmaxsvd,
        favgsvd,
        fminsvd,
        fmaxsv,
        favgsv,
        fminsv,
        fmaxsi,
        favgsi,
        fminsi,
        fmaxsr,
        favgsr,
        fminsr,
        fmaxst,
        favgst,
        fminst,
        fmaxsp,
        favgsp,
        fminsp);
end;

