create
    definer = root@`%` procedure p_refresh_area_consum_7day(IN fareaid int, IN fday datetime)
begin
DECLARE
fmaxusetimes int;
DECLARE
favgusetimes int;
DECLARE
fminusetimes int;
DECLARE
fmaxuseduration int;
DECLARE
favguseduration int;
DECLARE
fminuseduration int;
DECLARE
fmaxsqv int;
DECLARE
favgsqv int;
DECLARE
fminsqv int;
select max(f_use_times),
       avg(f_use_times),
       min(f_use_times),
       max(f_use_duration),
       avg(f_use_duration),
       min(f_use_duration),
       max(f_sqv),
       avg(f_sqv),
       min(f_sqv)
into
    fmaxusetimes ,
    favgusetimes ,
    fminusetimes,
    fmaxuseduration,
    favguseduration,
    fminuseduration,
    fmaxsqv,
    favgsqv,
    fminsqv
from dws_area_consum_day
where f_area_id = fareaid
  and date_sub(fday, interval 7 day) <= date (f_day);
delete
from ads_area_consum_7day
where f_area_id = fareaid and date (fday) = date ( f_day);
INSERT INTO ads_area_consum_7day (f_area_id,
                                  f_day,
                                  f_max_use_times,
                                  f_avg_use_times,
                                  f_min_use_times,
                                  f_max_use_duration,
                                  f_avg_use_duration,
                                  f_min_use_duration,
                                  f_max_sqv,
                                  f_avg_sqv,
                                  f_min_sqv)
VALUES (fareaid,
        fday,
        fmaxusetimes,
        favgusetimes,
        fminusetimes,
        fmaxuseduration,
        favguseduration,
        fminuseduration,
        fmaxsqv,
        favgsqv,
        fminsqv);
end;

