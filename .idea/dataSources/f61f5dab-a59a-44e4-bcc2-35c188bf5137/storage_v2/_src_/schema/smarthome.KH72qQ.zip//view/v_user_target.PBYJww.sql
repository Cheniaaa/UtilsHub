create definer = root@localhost view v_user_target as
select `smarthome`.`t_user_target`.`f_user_id`            AS `f_user_id`,
       `smarthome`.`t_user_target`.`f_area_id`            AS `f_area_id`,
       `smarthome`.`t_user_target`.`f_target_category_id` AS `f_target_category_id`,
       `smarthome`.`t_user_target`.`f_delegated`          AS `f_delegated`,
       `smarthome`.`t_user_target`.`f_operator_id`        AS `f_operator_id`,
       `smarthome`.`t_user_target`.`f_updated_time`       AS `f_updated_time`,
       `smarthome`.`t_organ`.`f_name`                     AS `f_organ_name`,
       `smarthome`.`t_area`.`f_path`                      AS `f_path`
from ((`smarthome`.`t_user_target` join `smarthome`.`t_area`
       on ((`smarthome`.`t_user_target`.`f_area_id` = `smarthome`.`t_area`.`f_id`))) join `smarthome`.`t_organ`
      on ((`smarthome`.`t_area`.`f_organ_id` = `smarthome`.`t_organ`.`f_id`)));

-- comment on column v_user_target.f_user_id not supported: 用户ID

-- comment on column v_user_target.f_area_id not supported: 区域ID

-- comment on column v_user_target.f_target_category_id not supported: 对象类型ID 0=所有类型

-- comment on column v_user_target.f_delegated not supported: 代操作 0=否

-- comment on column v_user_target.f_operator_id not supported: 操作员ID

-- comment on column v_user_target.f_updated_time not supported: 更新时间

-- comment on column v_user_target.f_organ_name not supported: 名称

-- comment on column v_user_target.f_path not supported: 区域绝对路径 以->分割的各级名称

