create
    definer = root@`%` procedure p_initial_battery_week()
BEGIN
-- 定义将插入到新表中数据的变量
DECLARE fuserid int;
DECLARE fprobeid int;
DECLARE fday datetime;

DECLARE done INT DEFAULT 0;
DECLARE cur1 CURSOR FOR
SELECT distinct f_user_id,1000,f_day FROM dws_battery_user_day;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=1;
OPEN cur1;
emp_loop:LOOP
FETCH cur1 INTO fuserid,fprobeid,fday;
IF done=1 THEN
	LEAVE emp_loop;
END IF;

call p_refresh_battery_user_week(fuserid,fprobeid,fday );

END LOOP emp_loop;
cLose cur1;

END;

