create definer = root@localhost view v_probe_channel as
select `smarthome`.`t_probe_channel`.`f_probe_id`                AS `f_probe_id`,
       `smarthome`.`t_probe_channel`.`f_channel`                 AS `f_channel`,
       `smarthome`.`t_probe_channel`.`f_state`                   AS `f_state`,
       `smarthome`.`t_probe_channel`.`f_target_category_id`      AS `f_target_category_id`,
       `smarthome`.`t_probe_channel`.`f_name`                    AS `f_name`,
       `smarthome`.`t_probe_channel`.`f_creation_time`           AS `f_creation_time`,
       `smarthome`.`t_probe_channel`.`f_control_code`            AS `f_control_code`,
       `smarthome`.`t_probe_channel`.`f_builtin_code`            AS `f_builtin_code`,
       `smarthome`.`t_probe_channel`.`f_mode`                    AS `f_mode`,
       `smarthome`.`t_probe_channel`.`f_temperature`             AS `f_temperature`,
       `smarthome`.`t_probe_channel`.`f_speed`                   AS `f_speed`,
       `smarthome`.`t_probe_channel`.`f_direction`               AS `f_direction`,
       `smarthome`.`t_probe_channel`.`f_options`                 AS `f_options`,
       `smarthome`.`t_probe`.`f_last_online_time`                AS `f_last_online_time`,
       `smarthome`.`t_probe_channel`.`f_state_cached`            AS `f_state_cached`,
       `smarthome`.`t_probe`.`f_channel_state`                   AS `f_channel_state`,
       `smarthome`.`t_probe_channel`.`f_power`                   AS `f_power`,
       `smarthome`.`t_probe_channel`.`f_intensity`               AS `f_intensity`,
       `smarthome`.`t_probe_channel`.`f_on_off_time`             AS `f_on_off_time`,
       `smarthome`.`t_probe_channel`.`f_target_category_icon_id` AS `f_target_category_icon_id`,
       `smarthome`.`t_probe_channel`.`f_keyboard`                AS `f_keyboard`,
       `smarthome`.`t_probe_channel`.`f_set_temperature`         AS `f_set_temperature`,
       `smarthome`.`t_probe_channel`.`f_ov_electricity`          AS `f_ov_electricity`,
       `smarthome`.`t_probe_channel`.`f_ov_alarm`                AS `f_ov_alarm`,
       `smarthome`.`t_probe_channel`.`f_ov_restore`              AS `f_ov_restore`,
       `smarthome`.`t_probe_channel`.`f_ov_alarm_value`          AS `f_ov_alarm_value`,
       `smarthome`.`t_probe_channel`.`f_ov_restore_value`        AS `f_ov_restore_value`,
       `smarthome`.`t_probe_channel`.`f_uv_electricity`          AS `f_uv_electricity`,
       `smarthome`.`t_probe_channel`.`f_uv_alarm`                AS `f_uv_alarm`,
       `smarthome`.`t_probe_channel`.`f_uv_restore`              AS `f_uv_restore`,
       `smarthome`.`t_probe_channel`.`f_uv_alarm_value`          AS `f_uv_alarm_value`,
       `smarthome`.`t_probe_channel`.`f_uv_restore_value`        AS `f_uv_restore_value`,
       `smarthome`.`t_probe_channel`.`f_ol_electricity`          AS `f_ol_electricity`,
       `smarthome`.`t_probe_channel`.`f_ol_alarm`                AS `f_ol_alarm`,
       `smarthome`.`t_probe_channel`.`f_ol_restore`              AS `f_ol_restore`,
       `smarthome`.`t_probe_channel`.`f_ol_alarm_value`          AS `f_ol_alarm_value`,
       `smarthome`.`t_probe_channel`.`f_ol_restore_value`        AS `f_ol_restore_value`,
       `smarthome`.`t_probe_channel`.`f_tem_electricity`         AS `f_tem_electricity`,
       `smarthome`.`t_probe_channel`.`f_tem_alarm`               AS `f_tem_alarm`,
       `smarthome`.`t_probe_channel`.`f_tem_restore`             AS `f_tem_restore`,
       `smarthome`.`t_probe_channel`.`f_tem_alarm_value`         AS `f_tem_alarm_value`,
       `smarthome`.`t_probe_channel`.`f_tem_restore_value`       AS `f_tem_restore_value`,
       `smarthome`.`t_probe_channel`.`f_switch_enable`           AS `f_switch_enable`,
       `smarthome`.`t_probe_channel`.`f_duration`                AS `f_duration`,
       `smarthome`.`t_probe_channel`.`f_battery_state`           AS `f_battery_state`,
       `smarthome`.`t_probe_channel`.`f_gear`                    AS `f_gear`,
       `smarthome`.`t_probe_channel`.`f_lp_electricity`          AS `f_lp_electricity`,
       `smarthome`.`t_probe_channel`.`f_lp_alarm`                AS `f_lp_alarm`,
       `smarthome`.`t_probe_channel`.`f_lp_restore`              AS `f_lp_restore`,
       `smarthome`.`t_probe_channel`.`f_lp_buzzer`               AS `f_lp_buzzer`,
       `smarthome`.`t_probe_channel`.`f_lp_run_time`             AS `f_lp_run_time`,
       `smarthome`.`t_probe_channel`.`f_ol_buzzer`               AS `f_ol_buzzer`,
       `smarthome`.`t_probe_channel`.`f_ov_buzzer`               AS `f_ov_buzzer`,
       `smarthome`.`t_probe_channel`.`f_uv_buzzer`               AS `f_uv_buzzer`,
       `smarthome`.`t_probe_channel`.`f_tem_buzzer`              AS `f_tem_buzzer`,
       `smarthome`.`t_probe_channel`.`f_run_time`                AS `f_run_time`,
       `smarthome`.`t_probe_channel`.`f_rest_time`               AS `f_rest_time`,
       `smarthome`.`t_gateway_host_probe`.`f_probe_version`      AS `f_probe_version`
from ((`smarthome`.`t_probe_channel` left join `smarthome`.`t_probe` on ((`smarthome`.`t_probe_channel`.`f_probe_id` =
                                                                          `smarthome`.`t_probe`.`f_id`))) left join `smarthome`.`t_gateway_host_probe`
      on ((`smarthome`.`t_probe_channel`.`f_probe_id` = `smarthome`.`t_gateway_host_probe`.`f_probe_id`)));

-- comment on column v_probe_channel.f_probe_id not supported: 探头ID

-- comment on column v_probe_channel.f_channel not supported: 通道号 唯一通道填0

-- comment on column v_probe_channel.f_state not supported: 状态 D2位=1禁用,D1位=1失联,D0位:0=关,1=开

-- comment on column v_probe_channel.f_target_category_id not supported: 监控对象类型

-- comment on column v_probe_channel.f_name not supported: 名称

-- comment on column v_probe_channel.f_creation_time not supported: 创建时间

-- comment on column v_probe_channel.f_control_code not supported: 控制码

-- comment on column v_probe_channel.f_builtin_code not supported: 是否内置码

-- comment on column v_probe_channel.f_mode not supported: 模式

-- comment on column v_probe_channel.f_temperature not supported: 温度

-- comment on column v_probe_channel.f_speed not supported: 风速

-- comment on column v_probe_channel.f_direction not supported: 风向

-- comment on column v_probe_channel.f_options not supported: 其他参数

-- comment on column v_probe_channel.f_last_online_time not supported: 最后在线间

-- comment on column v_probe_channel.f_state_cached not supported: 缓存状态 同状态

-- comment on column v_probe_channel.f_channel_state not supported: 通道状态 用位表示对应通道的开关

-- comment on column v_probe_channel.f_power not supported: 额定功率

-- comment on column v_probe_channel.f_intensity not supported: 信号强度

-- comment on column v_probe_channel.f_on_off_time not supported: 最后开关时间

-- comment on column v_probe_channel.f_target_category_icon_id not supported: 监控对象类型图标

-- comment on column v_probe_channel.f_keyboard not supported: 键盘锁：（0：所有键盘打开，1：模式按键锁定，2：风扇和模式按键锁定，3：仅开关机按键打开，4：锁定所有按键）

-- comment on column v_probe_channel.f_set_temperature not supported: 设定温度 26

-- comment on column v_probe_channel.f_ov_electricity not supported: 过压保护-自动断电

-- comment on column v_probe_channel.f_ov_alarm not supported: 过压保护-报警推送

-- comment on column v_probe_channel.f_ov_restore not supported: 过压保护-恢复推送

-- comment on column v_probe_channel.f_ov_alarm_value not supported: 过压保护-过压阈值

-- comment on column v_probe_channel.f_ov_restore_value not supported: 过压保护-恢复阈值

-- comment on column v_probe_channel.f_uv_electricity not supported: 欠压保护-自动断电

-- comment on column v_probe_channel.f_uv_alarm not supported: 欠压保护-报警推送

-- comment on column v_probe_channel.f_uv_restore not supported: 欠压保护-恢复推送

-- comment on column v_probe_channel.f_uv_alarm_value not supported: 欠压保护-欠压阈值

-- comment on column v_probe_channel.f_uv_restore_value not supported: 欠压保护-恢复阈值

-- comment on column v_probe_channel.f_ol_electricity not supported: 过载保护-自动断电

-- comment on column v_probe_channel.f_ol_alarm not supported: 过载保护-报警推送

-- comment on column v_probe_channel.f_ol_restore not supported: 过载保护-恢复推送

-- comment on column v_probe_channel.f_ol_alarm_value not supported: 过载保护-过载阈值

-- comment on column v_probe_channel.f_ol_restore_value not supported: 过载保护-恢复阈值

-- comment on column v_probe_channel.f_tem_electricity not supported: 温度保护-自动断电

-- comment on column v_probe_channel.f_tem_alarm not supported: 温度保护-报警推送

-- comment on column v_probe_channel.f_tem_restore not supported: 温度保护-恢复推送

-- comment on column v_probe_channel.f_tem_alarm_value not supported: 温度保护-温度阈值

-- comment on column v_probe_channel.f_tem_restore_value not supported: 温度保护-恢复阈值

-- comment on column v_probe_channel.f_switch_enable not supported: 本地开关是否启用

-- comment on column v_probe_channel.f_duration not supported: 充电时长

-- comment on column v_probe_channel.f_battery_state not supported: 00000  d4=欠压d3=过压d2=过载d1=温度d0=充电

-- comment on column v_probe_channel.f_gear not supported: 挡位

-- comment on column v_probe_channel.f_lp_electricity not supported: 低压自动断电

-- comment on column v_probe_channel.f_lp_alarm not supported: 低压报警推送

-- comment on column v_probe_channel.f_lp_restore not supported: 低压恢复推送

-- comment on column v_probe_channel.f_lp_buzzer not supported: 允许低压蜂鸣器提示

-- comment on column v_probe_channel.f_lp_run_time not supported: 低压运行时间（小时）

-- comment on column v_probe_channel.f_ol_buzzer not supported: 允许过载蜂鸣器提示

-- comment on column v_probe_channel.f_ov_buzzer not supported: 允许过压蜂鸣器提示

-- comment on column v_probe_channel.f_uv_buzzer not supported: 允许欠压蜂鸣器提示

-- comment on column v_probe_channel.f_tem_buzzer not supported: 允许超温蜂鸣器提示

-- comment on column v_probe_channel.f_run_time not supported: 探头运行时长

-- comment on column v_probe_channel.f_rest_time not supported: 重置时间

