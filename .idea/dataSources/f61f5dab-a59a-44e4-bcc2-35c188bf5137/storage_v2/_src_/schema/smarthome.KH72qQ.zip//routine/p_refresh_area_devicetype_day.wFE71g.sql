create
    definer = root@`%` procedure p_refresh_area_devicetype_day(IN fareaid int, IN fdevicetype int, IN fday datetime)
begin
DECLARE
fsqv bigint;-- 设备类型用电量
DECLARE
fsqvall bigint; -- 总用电量
DECLARE
fsqvprop bigint;-- 比例
select sum(f_sqv)
into
    fsqv
from dws_device_day
         INNER JOIN t_probe on t_probe.f_id = dws_device_day.f_probe_id
where t_probe.f_area_id = fareaid
  and t_probe.f_probe_kind_code = fdevicetype
  and DATE_FORMAT(fday, "%Y-%m-%d") = DATE_FORMAT(f_day, "%Y-%m-%d");
select sum(f_sqv)
into
    fsqvall
from dws_device_day
         INNER JOIN t_probe on t_probe.f_id = dws_device_day.f_probe_id
where t_probe.f_area_id = fareaid
  and DATE_FORMAT(fday, "%Y-%m-%d") = DATE_FORMAT(f_day, "%Y-%m-%d");
set
fsqvprop = if(fsqvall = 0 , 0 , fsqv*1000/fsqvall);
delete
from ads_area_devicetype_day
where f_area_id = fareaid
  and f_devicetype_id = fdevicetype
  and DATE_FORMAT(fday, "%Y-%m-%d") = DATE_FORMAT(f_day, "%Y-%m-%d");
INSERT INTO ads_area_devicetype_day (f_area_id,
                                     f_devicetype_id,
                                     f_day,
                                     f_sqv,
                                     f_sqv_prop)
VALUES (fareaid,
        fdevicetype,
        fday,
        fsqv,
        fsqvprop);
end;

