create definer = root@`%` view v_device_working_time as
select `wrd`.`f_probe_id`      AS `f_probe_id`,
       `wrd`.`f_probe_channel` AS `f_probe_channel`,
       `wr`.`f_work_type`      AS `f_work_type`,
       `wr`.`f_start_time`     AS `f_start_time`,
       `wr`.`f_end_time`       AS `f_end_time`,
       `t`.`f_day_type`        AS `f_day_type`,
       `t`.`f_customer_id`     AS `f_customer_id`
from ((`smarthome`.`t_working_rule` `wr` join `smarthome`.`t_working_rule_device` `wrd`
       on ((`wr`.`f_id` = `wrd`.`f_working_rule_id`))) join (select `smarthome`.`t_customer`.`f_id`                  AS `f_customer_id`,
                                                                    ifnull(`smarthome`.`t_calendar`.`f_day_type`, 1) AS `f_day_type`
                                                             from (`smarthome`.`t_customer` left join `smarthome`.`t_calendar`
                                                                   on (((`smarthome`.`t_customer`.`f_id` =
                                                                         `smarthome`.`t_calendar`.`f_customer_id`) and
                                                                        (`smarthome`.`t_calendar`.`f_day` = curdate()))))) `t`
      on (((`wr`.`f_day_type` = `t`.`f_day_type`) and (`wr`.`f_customer_id` = `t`.`f_customer_id`))));

-- comment on column v_device_working_time.f_probe_id not supported: 探头ID

-- comment on column v_device_working_time.f_probe_channel not supported: 探头通道

-- comment on column v_device_working_time.f_work_type not supported: 工作类型

-- comment on column v_device_working_time.f_start_time not supported: 开始时间

-- comment on column v_device_working_time.f_end_time not supported: 结束时间

-- comment on column v_device_working_time.f_customer_id not supported: ID

