create definer = root@localhost view v_group_target as
select `smarthome`.`t_group_area`.`f_group_id`             AS `f_group_id`,
       `smarthome`.`t_area`.`f_id`                         AS `f_area_id`,
       `smarthome`.`t_area`.`f_path`                       AS `f_path`,
       `smarthome`.`t_organ`.`f_name`                      AS `f_organ_name`,
       `smarthome`.`t_group_target`.`f_target_category_id` AS `f_target_category_id`,
       `smarthome`.`t_group_target`.`f_delegated`          AS `f_delegated`
from (((`smarthome`.`t_group_area` join `smarthome`.`t_area`
        on ((`smarthome`.`t_group_area`.`f_area_id` = `smarthome`.`t_area`.`f_id`))) join `smarthome`.`t_organ`
       on ((`smarthome`.`t_area`.`f_organ_id` = `smarthome`.`t_organ`.`f_id`))) join `smarthome`.`t_group_target`
      on (((`smarthome`.`t_group_area`.`f_group_id` = `smarthome`.`t_group_target`.`f_group_id`) and
           (`smarthome`.`t_group_area`.`f_area_id` = `smarthome`.`t_group_target`.`f_area_id`))));

-- comment on column v_group_target.f_group_id not supported: 组ID

-- comment on column v_group_target.f_area_id not supported: 区域ID

-- comment on column v_group_target.f_path not supported: 区域绝对路径 以->分割的各级名称

-- comment on column v_group_target.f_organ_name not supported: 名称

-- comment on column v_group_target.f_target_category_id not supported: 对象类型ID 0=所有类型

-- comment on column v_group_target.f_delegated not supported: 代操作 0=否

